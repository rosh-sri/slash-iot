# Smart-Baggage-Tracker-using-IoT
A smart luggage tracking system gives highly precise real-time location based information to the user. Lost luggage issues at airports are very common these days. Also, it is one section where no prominent improvement steps were taken.

<img width="921" alt="Screenshot 2024-01-12 at 6 42 49 PM" src="https://github.com/Abhinavreddy20/Smart-Baggage-Tracker-using-IoT-/assets/143411869/fc71c602-856e-4b4b-9233-c8d391300b98">

<img width="921" alt="Screenshot 2024-01-12 at 6 42 22 PM" src="https://github.com/Abhinavreddy20/Smart-Baggage-Tracker-using-IoT-/assets/143411869/2a45fc6c-d0b2-46fe-8300-25b505faefa4">
