IoT based smart cradle system give convenience and surveillance to parent in real time as compared to conventional cradle It also ensure baby safety while they are not physically present near cradle, so it is efficient to use IOT based smart cradle system to take care of infant in proficient manner.# Smart-Cradle-System-using-IoT


<img width="826" alt="Screenshot 2024-01-12 at 12 49 02 PM" src="https://github.com/Abhinavreddy20/Smart-Cradle-System-using-IoT/assets/143411869/20399433-190b-40ee-a0fd-a1ae580809fd">


<img width="826" alt="Screenshot 2024-01-12 at 12 49 15 PM" src="https://github.com/Abhinavreddy20/Smart-Cradle-System-using-IoT/assets/143411869/4c495051-453c-41f1-9d86-0bcd11e08da1">
