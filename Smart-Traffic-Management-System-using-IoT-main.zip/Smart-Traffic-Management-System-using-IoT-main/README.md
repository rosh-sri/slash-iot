# Smart-Traffic-Management-System-using-IoT

IoT sensors can monitor important safety elements on the vehicles themselves, like tire pressure, and alert drivers to any issues. IoT devices can also follow the cars in real-time, redirecting drivers to the most efficient route or allowing the owners to track the vehicle from a computer.

<img width="826" alt="Screenshot 2024-01-12 at 1 04 01 PM" src="https://github.com/Abhinavreddy20/Smart-Traffic-Management-System-using-IoT/assets/143411869/4ade98ec-360b-416c-8a0b-2074fe8da97a">

<img width="826" alt="Screenshot 2024-01-12 at 1 04 32 PM" src="https://github.com/Abhinavreddy20/Smart-Traffic-Management-System-using-IoT/assets/143411869/a3328204-458a-407d-bb13-c65134e2cce6">

<img width="826" alt="Screenshot 2024-01-12 at 1 04 19 PM" src="https://github.com/Abhinavreddy20/Smart-Traffic-Management-System-using-IoT/assets/143411869/0fe7496a-a757-4d72-8121-25a55899ed72">
