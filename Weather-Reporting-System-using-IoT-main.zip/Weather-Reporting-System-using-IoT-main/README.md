# Weather-Reporting-System-using-IoT
![Screenshot 2024-03-02 135234](https://github.com/saivarshith18/Weather-Reporting-System-using-IoT/assets/139994815/e41a76dc-d0a1-4e98-9b58-85c46a48113b)
![Screenshot 2024-03-02 135251](https://github.com/saivarshith18/Weather-Reporting-System-using-IoT/assets/139994815/f920b1b6-4493-4085-a479-caefba5990e2)
![Screenshot 2024-03-02 135304](https://github.com/saivarshith18/Weather-Reporting-System-using-IoT/assets/139994815/51112ef5-1777-46b3-92ed-8bd2cc8f5f78)
